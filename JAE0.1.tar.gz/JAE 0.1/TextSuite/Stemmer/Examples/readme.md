Stemmer documentation:

The stemmer works along the following process:
	a) Tokenization of sentences into words
	b) Tagging the words by their parts of speech
	c) Using their POS tags to search the WordNet dictionary for root forms

Once it obtains the root forms, it replaces the word by its root form. It is important to note that 
100% is nearly impossible without overfitting because some words can be used as multiple parts of a 
sentence. For example, in the sentence "The running man was bitten by the wolves", the only words that
should be stemmed are "bitten" and "wolves", because running is a verbal adjective (participle).

How to run:

	a) Input the file to be stemmed in ../Examples/
	b) Make sure the config file is updated with the new file paths for the input and desired output file
	c) Run stemmer.py from the command line to obtain an output file where inflected forms are stemmed.