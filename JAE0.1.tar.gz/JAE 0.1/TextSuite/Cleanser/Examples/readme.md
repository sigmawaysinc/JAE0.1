Cleanser documentation:

How to run:

	a) Input the file to be corrected in ../Examples
	b) Make sure the config file is updated with the new file paths for the input and desired output files.
	c) Mark whatever you wish to do as True in the config file. If left blank, the program assumes it is False.