Classifier documentation:

The classifier works along the following process:
	a) Extraction of pretagged files ('training of the classifier')
	b) Extraction of features from training files, and fitting them to prewritten labels
	c) The features in this case include N-Grams and words (we use N-grams for accuracy)
	d) Fitting of labeled features to a classifier (MNB in this case)
	e) Extraction of the same features from the test set (the file we input to check)
	f) Labeling the features according to the classifier
	g) Computes and returns the most probable language

How to run:

	a) Input the file to be corrected in ../Examples
	b) Make sure the config file is updated with the new file path for the input file
	c) Run langcl.py from the command line to obtain the language of the input file.