Spellchecker documentation:

The spellchecker works along the following process:
	a) Compares each word against a dictionary
	b) If it finds a word not in the given dictionary, it will compute the Levenshtein distance
	c) Based on the Levenshtein distance, it will delete, replace or insert letters

How to run:

	a) Input the file to be corrected in ../Examples/
	b) Make sure the config file is updated with the new file paths for the input and desired output file
	c) Run spellcheck.py from the command line to obtain an output file where incorrected words are corrected.