import pandas as pds
import numpy as np
import matplotlib.pyplot as plt
import string
import ConfigParser

config = ConfigParser.ConfigParser()
config.read('../Conf/churn_config.ini')
filename = config.get('File Parameters', 'Input Dataset')
drop_cols = config.get('File Parameters', 'Columns to drop').split(",")
run_kme_t = config.get('Algorithms', 'KME Table')
run_kme_p = config.get('Algorithms', 'KME Plot')
cfg_rf = config.get('Algorithms', 'Random Forest')
cfg_svm = config.get('Algorithms', 'Support Vector Machine')
cfg_lr = config.get('Algorithms', 'Logistic Regression')
cfg_knn = config.get('Algorithms', 'Nearest Neighbor')
cfg_gnb = config.get('Algorithms', 'Naive Bayes')
cfg_gnb_out = config.get('Output Files', 'Naive Bayes')
cfg_knn_out = config.get('Output Files', 'Nearest Neighbor')
cfg_lr_out = config.get('Output Files', 'Logistic Regression')
cfg_svm_out = config.get('Output Files', 'Support Vector Machine')
cfg_rf_out = config.get('Output Files', 'Random Forest')
cfg_kme_out = config.get('Output Files', 'KME Table')

churn_training = pds.read_csv(filename)

# We establish the base churn rate using Kaplan-Meier Estimators
from lifelines import KaplanMeierFitter


def KME_table():
    Account_length = churn_training.AccountLength
    Churn_train_set = churn_training.Churn
    output_file = config.get('File functions', 'KME Output')
    output_file = open(../Data/output_file, 'w')
    print >> output_file, "%r,%s" % (Account_length, Churn_train_set)
    output_file.close()


def KME_plot():
    kme = KaplanMeierFitter()
    Account_length = churn_training.AccountLength
    Churn_train_set = churn_training.Churn
    kme.fit(Account_length, event_observed=Churn_train_set)
    print "Survival Function"
    print kme.survival_function_
    print "Median"
    print kme.median_
    kme.fit(Account_length, Churn_train_set, label="Base Churn Rate Test")
    kme.plot()
    plt.savefig('../Data/KM Plot 2.png')


churn_feat_space = churn_training.drop(drop_cols, axis=1)
feature_points = churn_feat_space.columns
y = np.where(churn_training['Churn'] == 1, 1, 0)
# As Matrix
X = churn_feat_space.as_matrix().astype(np.float)

# Standardizes the dataset by removing the mean and
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X = scaler.fit_transform(X)
print "Feature space holds %d observations and %d features" % X.shape
print "Unique target labels:", np.unique(y)

# Testing the model
from sklearn.cross_validation import KFold


# Compares the predicted column with the actual column using
# cross validation
def cross_val(X, y, clf_class, **kwargs):
    kf = KFold(len(y), n_folds=5, shuffle=True)
    y_pred = y.copy()
    
    for train_index, test_index in kf:
        X_train, X_test = X[train_index], X[test_index]
        y_train = y[train_index]
        clf = clf_class(**kwargs)
        clf.fit(X_train, y_train)
        y_pred[test_index] = clf.predict(X_test)
    return y_pred


# Checks the accuracy of the algorithm
def accuracy(y_true, y_pred):
    return np.mean(y_true == y_pred)


from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier as rf
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier as kn
from sklearn.linear_model import LogisticRegression as lr
from sklearn.naive_bayes import GaussianNB as gnb


def random_forest():
    rf_acc = accuracy(y, cross_val(X, y, rf))
    confusion_rf = [("Random Forest", confusion_matrix(y, cross_val(X, y, rf)))]
    rf_confmat = confusion_rf[0][1]
    fig, ax = plt.subplots(figsize=(2.5, 2.5))
    ax.matshow(rf_confmat, cmap=plt.cm.Blues, alpha=0.3)
    rf_mat = np.asarray(rf_confmat)
    np.savetxt(cfg_rf_out, rf_mat, delimiter=",")
    for i in range(rf_confmat.shape[0]):
        for j in range(rf_confmat.shape[1]):
            ax.text(x=j, y=i, s=rf_confmat[i, j], va='center', ha='center')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix for RF')
    plt.plot()
    plt.savefig('rf.png')
    return rf_acc


def support_vector_machine():
    svm_acc = accuracy(y, cross_val(X, y, SVC))
    confusion_svm = [("SVM", confusion_matrix(y, cross_val(X, y, SVC)))]
    svm_confmat = confusion_svm[0][1]
    svm_mat = np.asarray(svm_confmat)
    np.savetxt(cfg_svm_out, svm_mat, delimiter=",")
    fig, ax = plt.subplots(figsize=(2.5, 2.5))
    ax.matshow(svm_confmat, cmap=plt.cm.Blues, alpha=0.3)
    for i in range(svm_confmat.shape[0]):
        for j in range(svm_confmat.shape[1]):
            ax.text(x=j, y=i, s=svm_confmat[i, j], va='center', ha='center')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix for SVM')
    plt.plot()
    plt.savefig('svm.png')
    return svm_acc


def Gauss_Naive():
    gnb_acc = accuracy(y, cross_val(X, y, gnb))
    confusion_gnb = [("Gaussian Naive Bayes", confusion_matrix(y, cross_val(X, y, gnb)))]
    gnb_confmat = confusion_gnb[0][1]
    gnb_mat = np.asarray(gnb_confmat)
    np.savetxt(cfg_gnb_out, gnb_mat, delimiter=",")
    fig, ax = plt.subplots(figsize=(2.5, 2.5))
    ax.matshow(gnb_confmat, cmap=plt.cm.Blues, alpha=0.3)
    for i in range(gnb_confmat.shape[0]):
        for j in range(gnb_confmat.shape[1]):
            ax.text(x=j, y=i, s=gnb_confmat[i, j], va='center', ha='center')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix for Gaussian Naive Bayes')
    plt.plot()
    plt.savefig('gnb.png')
    return gnb_acc


def nearest_neighbor():
    knn_acc = accuracy(y, cross_val(X, y, kn))
    confusion_kn = [("Nearest neighbor", confusion_matrix(y, cross_val(X, y, kn)))]
    knn_confmat = confusion_kn[0][1]
    knn_mat = np.asarray(knn_confmat)
    np.savetxt(cfg_knn_out, knn_mat, delimiter=",")
    fig, ax = plt.subplots(figsize=(2.5, 2.5))
    ax.matshow(knn_confmat, cmap=plt.cm.Blues, alpha=0.3)
    for i in range(knn_confmat.shape[0]):
        for j in range(knn_confmat.shape[1]):
            ax.text(x=j, y=i, s=knn_confmat[i, j], va='center', ha='center')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix for KNN')
    plt.plot()
    plt.savefig('knn.png')
    return knn_acc


def logistic_reg():
    lr_acc = accuracy(y, cross_val(X, y, lr))
    confusion_lr = [("Logistic Regression", confusion_matrix(y, cross_val(X, y, lr)))]
    lr_confmat = confusion_lr[0][1]
    lr_mat = np.asarray(lr_confmat)
    np.savetxt(cfg_lr_out, lr_mat, delimiter=",")
    fig, ax = plt.subplots(figsize=(2.5, 2.5))
    ax.matshow(lr_confmat, cmap=plt.cm.Blues, alpha=0.3)
    for i in range(lr_confmat.shape[0]):
        for j in range(lr_confmat.shape[1]):
            ax.text(x=j, y=i, s=lr_confmat[i, j], va='center', ha='center')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix for LR')
    plt.plot()
    plt.show()
    plt.savefig('lr.png')
    return lr_acc


def main():
    if run_kme_t == 'True':
        KME_table()
    if run_kme_p == 'True':
        KME_plot()
    if cfg_rf == 'True':
        random_forest()
        rforest = random_forest()
        print "Random Forest Accuracy = "
        print "%0.5f" % rforest
    if cfg_svm == 'True':
        support_vector_machine()
        svmachine = support_vector_machine()
        print "SVM Accuracy = "
        print "%0.5f" % svmachine
    if cfg_knn == 'True':
        nearest_neighbor()
        knearest = nearest_neighbor()
        print "Nearest Neighbor Accuracy = "
        print "%0.5f" % knearest
    if cfg_gnb == 'True':
        Gauss_Naive()
        gauss = Gauss_Naive()
        print "Naive Bayes Accuracy = "
        print "%0.5f" % gauss
    if cfg_rf == 'True':
        logistic_reg()
        logist = logistic_reg()
        print "Logistic Regression Accuracy = "
        print "%0.5f" % logist

main()
